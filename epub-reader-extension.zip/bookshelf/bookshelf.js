import { BookStore } from '../core/BookStore.js';

const grid = document.getElementById('book-grid');
const emptyState = document.getElementById('empty-state');
const btnAdd = document.getElementById('btn-add');
const fileInput = document.getElementById('file-input');
const dropOverlay = document.getElementById('drop-overlay');

async function init() {
  await renderShelf();
  setupDragDrop();
}

async function renderShelf() {
  const books = await BookStore.getAllBooks();
  books.sort((a, b) => (b.lastReadAt || b.addedAt) - (a.lastReadAt || a.addedAt));
  grid.innerHTML = '';

  if (books.length === 0) {
    emptyState.classList.remove('hidden');
    return;
  }
  emptyState.classList.add('hidden');

  for (const book of books) {
    const pos = await BookStore.getPosition(book.id);
    grid.appendChild(createCard(book, pos?.scrollPercent ?? 0));
  }
}

function createCard(book, progress) {
  const card = document.createElement('div');
  card.className = 'book-card';
  card.dataset.id = book.id;

  const coverHtml = book.coverDataUrl
    ? `<img class="book-cover" src="${book.coverDataUrl}" alt="">`
    : `<div class="book-cover-placeholder">📖</div>`;

  card.innerHTML = `
    ${coverHtml}
    <div class="book-info">
      <div class="book-title" title="${escHtml(book.title)}">${escHtml(book.title)}</div>
      <div class="book-author">${escHtml(book.author)}</div>
      <div class="book-progress"><div class="book-progress-bar" style="width:${Math.round(progress * 100)}%"></div></div>
    </div>
    <div class="book-actions">
      <button class="btn-delete" title="删除" data-id="${book.id}">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>`;

  card.querySelector('.btn-delete').addEventListener('click', async (e) => {
    e.stopPropagation();
    if (confirm(`删除《${book.title}》？`)) {
      await BookStore.deleteBook(book.id);
      await renderShelf();
    }
  });

  card.addEventListener('click', () => openBook(book.id));
  return card;
}

async function openBook(id) {
  const book = await BookStore.getBook(id);
  if (!book) return;

  // Verify we can access the file before opening the reader tab
  if (book.fileHandle) {
    try {
      const perm = await book.fileHandle.queryPermission({ mode: 'read' });
      if (perm !== 'granted') {
        const req = await book.fileHandle.requestPermission({ mode: 'read' });
        if (req !== 'granted') { alert('需要文件访问权限才能打开此书'); return; }
      }
    } catch (err) {
      alert('无法访问文件，请重新添加此书。\n' + err.message);
      return;
    }
  } else if (!book.fileBlob) {
    alert('找不到文件内容，请重新添加此书。');
    return;
  }

  await BookStore.updateLastRead(id);
  const url = chrome.runtime.getURL(`reader/reader.html?id=${id}`);
  chrome.tabs.create({ url });
}

async function addFiles(files) {
  for (const file of files) {
    if (!file.name.endsWith('.epub')) continue;
    await importEpub(file, null);
  }
  await renderShelf();
}

async function addHandles(handles) {
  for (const handle of handles) {
    if (!handle.name.endsWith('.epub')) continue;
    const file = await handle.getFile();
    await importEpub(file, handle);
  }
  await renderShelf();
}

async function importEpub(file, fileHandle) {
  let title = file.name.replace(/\.epub$/i, '');
  let author = '';
  let coverDataUrl = null;

  try {
    const buffer = await file.arrayBuffer();
    const book = ePub(buffer);
    await book.ready;
    await book.loaded.metadata;

    const meta = book.package.metadata;
    title  = meta.title   || title;
    author = meta.creator || '';

    // Fetch cover BEFORE destroy — coverUrl is a blob: URL that gets revoked on destroy
    try {
      const coverUrl = await book.coverUrl();
      if (coverUrl) {
        const resp = await fetch(coverUrl);
        const blob = await resp.blob();
        coverDataUrl = await blobToDataUrl(blob);
      }
    } catch (_) {}

    book.destroy();
  } catch (e) {
    console.error('epub 解析失败:', e);
  }

  // fileHandle (from showOpenFilePicker) is natively clonable by IndexedDB.
  // When only a File is available (drag-drop), store raw bytes as fallback.
  let fileBlob = null;
  if (!fileHandle) {
    fileBlob = await file.arrayBuffer();
  }

  await BookStore.addBook({
    id: crypto.randomUUID(),
    title,
    author,
    coverDataUrl,
    fileHandle: fileHandle || null,
    fileBlob,              // ArrayBuffer fallback for drag-drop
    fileName: file.name,
    addedAt: Date.now(),
    lastReadAt: null,
  });
}

function blobToDataUrl(blob) {
  return new Promise((resolve) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.readAsDataURL(blob);
  });
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// File picker button — uses File System Access API for persistent handles
btnAdd.addEventListener('click', async () => {
  try {
    const handles = await window.showOpenFilePicker({
      types: [{ description: 'EPUB 电子书', accept: { 'application/epub+zip': ['.epub'] } }],
      multiple: true,
    });
    await addHandles(handles);
  } catch (e) {
    if (e.name !== 'AbortError') console.error(e);
  }
});

// Fallback file input
fileInput.addEventListener('change', async () => {
  await addFiles(Array.from(fileInput.files));
  fileInput.value = '';
});

// Drag and drop — prefer FileSystemFileHandle via getAsFileSystemHandle() for persistence
function setupDragDrop() {
  let dragCounter = 0;
  document.addEventListener('dragenter', (e) => {
    e.preventDefault();
    dragCounter++;
    dropOverlay.classList.remove('hidden');
  });
  document.addEventListener('dragleave', () => {
    dragCounter--;
    if (dragCounter <= 0) { dragCounter = 0; dropOverlay.classList.add('hidden'); }
  });
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', async (e) => {
    e.preventDefault();
    dragCounter = 0;
    dropOverlay.classList.add('hidden');

    const items = Array.from(e.dataTransfer.items || []);
    if (items.length && items[0].getAsFileSystemHandle) {
      const handles = await Promise.all(items.map(i => i.getAsFileSystemHandle()));
      await addHandles(handles.filter(h => h?.kind === 'file' && h.name.endsWith('.epub')));
    } else {
      await addFiles(Array.from(e.dataTransfer.files));
    }
  });
}

init();
