import { BookStore } from '../core/BookStore.js';
import { SettingsStore } from '../core/SettingsStore.js';
import { EpubReader } from '../core/EpubReader.js';

const params = new URLSearchParams(location.search);
const bookId = params.get('id');

const loading = document.getElementById('loading');
const readerArea = document.getElementById('reader-area');
const chapterTitle = document.getElementById('chapter-title');
const btnBack = document.getElementById('btn-back');
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
const btnToc = document.getElementById('btn-toc');
const btnSettings = document.getElementById('btn-settings');
const tocPanel = document.getElementById('toc-panel');
const tocClose = document.getElementById('toc-close');
const tocList = document.getElementById('toc-list');
const settingsPanel = document.getElementById('settings-panel');
const settingsClose = document.getElementById('settings-close');
const progressFill = document.getElementById('progress-fill');
const progressLabel = document.getElementById('progress-label');

// Settings controls
const modeToggle = document.getElementById('mode-toggle');
const themeSwatches = document.getElementById('theme-swatches');
const fontSizeSlider = document.getElementById('font-size');
const fontSizeVal = document.getElementById('font-size-val');
const fontFamilySelect = document.getElementById('font-family');

let reader = null;
let settings = null;
let saveTimer = null;

async function init() {
  if (!bookId) { showError('未指定书籍'); return; }

  const book = await BookStore.getBook(bookId);
  if (!book) { showError('找不到书籍信息'); return; }

  // Get file — prefer FileSystemFileHandle, fall back to stored ArrayBuffer
  let file;
  try {
    if (book.fileHandle) {
      const perm = await book.fileHandle.queryPermission({ mode: 'read' });
      if (perm !== 'granted') await book.fileHandle.requestPermission({ mode: 'read' });
      file = await book.fileHandle.getFile();
    } else if (book.fileBlob) {
      file = new File([book.fileBlob], book.fileName || 'book.epub', { type: 'application/epub+zip' });
    } else {
      showError('找不到文件内容，请在书架重新添加此书。');
      return;
    }
  } catch (e) {
    showError('无法访问文件：' + e.message);
    return;
  }

  settings = await SettingsStore.get();
  applyThemeToPage(settings.theme);

  reader = new EpubReader();
  try {
    const meta = await reader.open(file);
    document.title = meta.title + ' — Epub Reader';
    buildToc(meta.toc);
  } catch (e) {
    showError('epub 解析失败：' + e.message);
    return;
  }

  const readerWrap = document.getElementById('reader-wrap');

  // In scroll mode, hide loading as soon as first chapter is ready
  const onFirstChapter = settings.readingMode === 'scroll'
    ? () => { loading.classList.add('hidden'); loadSettingsUI(); setupUI(); }
    : null;

  await reader.renderTo(readerArea, settings.readingMode, readerWrap, onFirstChapter);
  reader.applySettings(settings);
  updateModeUI(settings.readingMode);

  // Restore reading position
  const pos = await BookStore.getPosition(bookId);
  if (pos) await reader.goTo(pos);

  reader.onLocationChange((loc) => {
    if (!loc) return;
    chapterTitle.textContent = loc.chapterTitle || '';
    const pct = Math.round((loc.scrollPercent || 0) * 100);
    progressFill.style.width = pct + '%';
    progressLabel.textContent = pct + '%';
    scheduleSave(loc);
  });

  // Scroll mode: track progress bar via scroll events on the wrap element
  if (settings.readingMode === 'scroll') {
    readerWrap.addEventListener('scroll', () => {
      const total = readerWrap.scrollHeight - readerWrap.clientHeight;
      if (total <= 0) return;
      const pct = Math.round((readerWrap.scrollTop / total) * 100);
      progressFill.style.width = pct + '%';
      progressLabel.textContent = pct + '%';
    }, { passive: true });
  }

  // Paginated mode: hide loading after renderTo returns
  if (settings.readingMode !== 'scroll') {
    loading.classList.add('hidden');
    loadSettingsUI();
    setupUI();
  }
}

function scheduleSave(loc) {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    BookStore.savePosition(bookId, {
      cfi: loc.cfi,
      scrollPercent: loc.scrollPercent,
      chapterHref: loc.chapterHref,
      chapterFraction: loc.chapterFraction,
    });
  }, 1000);
}

async function saveNow() {
  clearTimeout(saveTimer);
  const loc = await reader?.getCurrentLocation();
  if (loc) await BookStore.savePosition(bookId, {
    cfi: loc.cfi,
    scrollPercent: loc.scrollPercent,
    chapterHref: loc.chapterHref,
    chapterFraction: loc.chapterFraction,
  });
}

function applyThemeToPage(theme) {
  document.body.className = `theme-${theme}`;
}

function updateModeUI(mode) {
  document.body.classList.toggle('mode-scroll', mode === 'scroll');
  modeToggle.querySelectorAll('button').forEach(b => {
    b.classList.toggle('active', b.dataset.value === mode);
  });
}

function buildToc(toc) {
  tocList.innerHTML = '';
  for (const item of toc) {
    const el = document.createElement('div');
    el.className = `toc-item toc-depth-${Math.min(item.depth, 2)}`;
    el.textContent = item.label;
    el.addEventListener('click', () => {
      reader.goTo({ chapterHref: item.href, cfi: item.href });
      tocPanel.classList.add('hidden');
    });
    tocList.appendChild(el);
  }
}

function loadSettingsUI() {
  fontSizeSlider.value = settings.fontSize;
  fontSizeVal.textContent = settings.fontSize;
  fontFamilySelect.value = settings.fontFamily;
  document.querySelectorAll('[data-theme]').forEach(b => {
    b.classList.toggle('active', b.dataset.theme === settings.theme);
  });
  updateModeUI(settings.readingMode);
}

async function updateSettings(patch) {
  Object.assign(settings, patch);
  await SettingsStore.set(patch);
  reader?.applySettings(settings);
  if (patch.theme) applyThemeToPage(patch.theme);
  if (patch.readingMode) {
    await saveNow();
    updateModeUI(patch.readingMode);
    reader.destroy();
    reader = new EpubReader();
    const book = await BookStore.getBook(bookId);
    const file = book.fileHandle
      ? await book.fileHandle.getFile()
      : new File([book.fileBlob], book.fileName || 'book.epub', { type: 'application/epub+zip' });
    await reader.open(file);
    await reader.renderTo(readerArea, patch.readingMode, document.getElementById('reader-wrap'));
    reader.applySettings(settings);
    const pos = await BookStore.getPosition(bookId);
    if (pos?.cfi) await reader.goTo(pos);
    reader.onLocationChange((loc) => {
      if (!loc) return;
      chapterTitle.textContent = loc.chapterTitle || '';
      const pct = Math.round((loc.scrollPercent || 0) * 100);
      progressFill.style.width = pct + '%';
      progressLabel.textContent = pct + '%';
      scheduleSave(loc);
    });
  }
}

function setupUI() {
  btnBack.addEventListener('click', async () => {
    await saveNow();
    window.close();
  });

  btnPrev.addEventListener('click', () => reader?.prev());
  btnNext.addEventListener('click', () => reader?.next());

  btnToc.addEventListener('click', () => {
    settingsPanel.classList.add('hidden');
    tocPanel.classList.toggle('hidden');
  });
  tocClose.addEventListener('click', () => tocPanel.classList.add('hidden'));

  btnSettings.addEventListener('click', () => {
    tocPanel.classList.add('hidden');
    settingsPanel.classList.toggle('hidden');
  });
  settingsClose.addEventListener('click', () => settingsPanel.classList.add('hidden'));

  // Close panels on outside click (use contains to handle clicks on SVG children)
  document.addEventListener('click', (e) => {
    if (!settingsPanel.contains(e.target) && !btnSettings.contains(e.target))
      settingsPanel.classList.add('hidden');
    if (!tocPanel.contains(e.target) && !btnToc.contains(e.target))
      tocPanel.classList.add('hidden');
  });

  // Settings controls
  fontSizeSlider.addEventListener('input', () => {
    fontSizeVal.textContent = fontSizeSlider.value;
    updateSettings({ fontSize: parseInt(fontSizeSlider.value, 10) });
  });

  fontFamilySelect.addEventListener('change', () => {
    updateSettings({ fontFamily: fontFamilySelect.value });
  });

  themeSwatches.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-theme]');
    if (!btn) return;
    themeSwatches.querySelectorAll('[data-theme]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    updateSettings({ theme: btn.dataset.theme });
  });

  modeToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-value]');
    if (!btn || btn.classList.contains('active')) return;
    updateSettings({ readingMode: btn.dataset.value });
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp' || e.key === 'PageUp')  reader?.prev();
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === 'PageDown') reader?.next();
    if (e.key === 'Escape') {
      tocPanel.classList.add('hidden');
      settingsPanel.classList.add('hidden');
    }
  });

  window.addEventListener('beforeunload', () => {
    // Synchronous save attempt on close (best-effort)
    saveNow();
  });
  document.addEventListener('visibilitychange', () => {
    // Save whenever tab becomes hidden (background, minimized, closed)
    if (document.visibilityState === 'hidden') saveNow();
  });
}

function showError(msg) {
  loading.innerHTML = `<p style="color:#ef4444;font-size:15px;">⚠️ ${msg}</p><a href="${chrome.runtime.getURL('bookshelf/bookshelf.html')}" style="margin-top:12px;color:#6366f1;">返回书库</a>`;
}

init();
